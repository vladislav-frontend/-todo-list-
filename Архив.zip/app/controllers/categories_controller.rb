class CategoriesController < ApplicationController

	before_action :set_category, only: [:show, :edit, :update, :destroy]

	# def index
	# 	@categories = Category.all
	# end

	# def show
	# end

	# def new
	# 	@category = Category.new
	# end

	def create
		@category = current_user.categories.new(category_params)

		if @category.save
			# redirect_to categories_path, success: 'Категория успешно создана'
			# render json: :ok
			render json: @category
		# else
		# 	render :new, danger: 'Категория не создана'
		end
	end

	# def edit
	# end

	def update
		if @category.update_attributes(category_params)
			render json: @category
		# else
		# 	render :edit, danger: 'Категория не обновлена'
		end
	end

	def destroy
		@category.destroy
		# redirect_to categories_path, success: 'Категория успешно удалена'
		render json: :ok
	end

	private

	def set_category
		@category = current_user.categories.find(params[:id])
	end

	def category_params
		params.permit(:name)
	end

end