class PostsController < ApplicationController

	before_action :authenticate_user!
	before_action :set_post, only: [:show, :edit, :update, :destroy]

	# def index
	# 	@posts = Post.all
	# end

	# def show
	# end

	# def new
	# 	@post = Post.new
	# end

	def create
		category = current_user.categories.find(params[:category_id])
		@post = category.posts.new(post_params)

		if @post.save
		# 	redirect_to @post, success: 'Пост успешно добавлен'
		# else
			render json: @post
		end
	end

	# def edit
	# end

	def update
		if @post.update_attributes(post_params)
		# 	redirect_to @post, success: 'Пост успешно обновлен'
		# else
			render json: @post
		end
	end

	def destroy
		@post.destroy
		# redirect_to posts_path, success: 'Пост успешно удален'
		render json: :ok
	end

	private

	def set_post
		@post = current_user.posts.find(params[:id])
	end

	def post_params
		params.permit(:title, :category_id, :checked, :datetime, :deadline)
	end
end